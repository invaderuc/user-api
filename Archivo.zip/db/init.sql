CREATE TABLE users (
  user_id binary(16) NOT NULL,
  name VARCHAR(50) NOT NULL,
  email VARCHAR(50) NOT NULL,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME DEFAULT NULL,
  updated_at DATETIME DEFAULT NULL,
  deleted_at DATETIME DEFAULT NULL,
  password VARCHAR(60) NOT NULL,
  PRIMARY KEY (user_id),
  CONSTRAINT email_unique UNIQUE (email)
);

CREATE TABLE phones ( 
  phone_id binary(16) NOT NULL,
  user_id binary(16) NOT NULL,
  phone_number VARCHAR(50) NOT NULL,
  cod_city VARCHAR(50) NOT NULL,
  cod_country VARCHAR(50) NOT NULL,
  is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
  created_at DATETIME DEFAULT NULL,
  updated_at DATETIME DEFAULT NULL,
  deleted_at DATETIME DEFAULT NULL,
  PRIMARY KEY (phone_id),
  CONSTRAINT fk_phones_users FOREIGN KEY(user_id)
  REFERENCES users(user_id)
);